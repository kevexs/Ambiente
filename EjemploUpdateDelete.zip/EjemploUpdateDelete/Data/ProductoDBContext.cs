﻿using Ejemplo.Models;
using Microsoft.EntityFrameworkCore;
using System;

namespace Ejemplo.Data
{
    public class ProductoDBContext : DbContext
    {

        public DbSet<Producto> Productos { get; set; }

        public ProductoDBContext(DbContextOptions<ProductoDBContext> options) 
            : base(options)
        {

                 }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            var productos = new Producto();
            productos.Id = 1;
            productos.Nombre = "Tornillos";
            productos.Precio = 1;


            modelBuilder.Entity<Producto>().HasData(productos);
        }
    }
}
